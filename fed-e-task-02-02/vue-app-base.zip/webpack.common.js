const path = require('path');
const VueLoaderPlugin = require('vue-loader/lib/plugin')
const HtmlWebpackPlugin = require('html-webpack-plugin');

const urlLimitSize = 4096;

module.exports = {
  entry: path.resolve(__dirname, './src/main.js'),
  output: {
    path: path.resolve(__dirname, 'dist')
  },
  module: {
    rules: [
      {
        test: /\.vue$/,
        use: 'vue-loader'
      },

      {
        test: /\.(png|jpe?g|gif|svg|)$/,
        use: {
          // loader: 'file-loader', over urlLimitSize use file-loader automatically
          loader: 'url-loader',
          options: {
            limit: urlLimitSize,
            name: 'assets/[name].[contenthash:6].[ext]',
            esModule: false
          }
        }
      }
    ]
  },

  plugins: [

    new VueLoaderPlugin(),
    new HtmlWebpackPlugin({
      title: 'Im a Vue App',
      template: './public/index.html'
    })
  ]
}
