const { merge } = require('webpack-merge')
const commonConfig = require('./webpack.common.js')
const webpack = require('webpack')
const path = require('path')

const devConfig = merge(commonConfig, {
  mode: 'development',
  output: {
    filename: 'js/app.js'
  },
  module: {
    rules: [
      {
        test: /\.(css|less)$/,
        use: [
          'vue-style-loader',
          'css-loader',
          'less-loader'
        ]
      }
    ]
  },

  devServer: {
    port: '8080',
    hot: true,
    open: true,
    compress: true,
    contentBase: path.join(__dirname, 'public')
  },
  plugins: [
    new webpack.HotModuleReplacementPlugin()
  ]
})

module.exports = devConfig;
